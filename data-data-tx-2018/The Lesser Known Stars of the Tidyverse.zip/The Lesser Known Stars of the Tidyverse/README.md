# Data Day Talk 2018

Here are my materials for my talk at Data Day Texas, the lesser known stars of the tidyverse. I will update this when the video of my talk is available in early February. In the meantime, you can view my slides (the pdf), the script I ran through (`data_day_talk_code.Rmd`), or a version of the script with much more explanation (`data_day_script_accompanying.Rmd`). 
